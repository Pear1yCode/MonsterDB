package model;

public class MoonDAO {
}
